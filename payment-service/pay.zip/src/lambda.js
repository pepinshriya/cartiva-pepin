const serverless = require('serverless-http');
const app = require('./app');

const paymentService = require('./services/payment.service');

const apiHandler = serverless(app);


module.exports.handler = async (event, context) => {


  // SQS Event Handling
  if (event.Records) {


    for (const record of event.Records) {


      const snsMessage =
        JSON.parse(record.body);


      const orderEvent =
        JSON.parse(snsMessage.Message);


      console.log(
        "Received Order Event:",
        orderEvent
      );


      if (
        orderEvent.eventType ===
        "ORDER_CREATED"
      ) {


        await paymentService.createPayment({

          orderId:
            orderEvent.data.orderId,

          userId:
            orderEvent.data.userId,

          amount:
            orderEvent.data.amount,

          paymentMethod:
            "CREDIT_CARD"

        });


      }


    }


    return {
      statusCode:200,
      body:"SQS processed"
    };

  }


  // Normal API Gateway requests
  return apiHandler(
    event,
    context
  );

};