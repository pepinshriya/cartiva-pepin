const paymentService = require('../services/payment.service');

module.exports.handler = async (event) => {
  for (const record of event.Records) {
    const snsMessage = JSON.parse(record.Sns.Message);

    if (snsMessage.eventType === 'ORDER_CREATED') {
      const { orderId, userId, amount } = snsMessage.data;

      console.log('Processing ORDER_CREATED for orderId:', orderId);

      await paymentService.createPaymentFromOrder({ orderId, userId, amount });

      console.log('Payment record created for orderId:', orderId);
    }
  }

  return { statusCode: 200 };
};